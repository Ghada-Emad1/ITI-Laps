import { createApp } from 'vue'
import Library from './Library.vue'

createApp(Library).mount('#app')
